# espanso

> Cross-platform Text Expander written in Rust.
> More information: <https://espanso.org/docs/command%20lIne/cli_list/>.

- Check status:

`espanso status`

- Edit the configuration:

`espanso edit config`

- Install a package from the hub store (<https://hub.espanso.org/>):

`espanso install {{package}}`

- Restart (required after installing a package, useful in case of failure):

`espanso restart`
