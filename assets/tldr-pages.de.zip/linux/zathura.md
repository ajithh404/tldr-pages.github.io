# zathura

> Ein vim-artiger, modaler Dokumentenbetrachter mit integrierter Kommandozeile.
> Benötigt ein installiertes Backend (poppler, Postscript oder DjVu).
> Weitere Informationen: <https://pwmt.org/projects/zathura/>.

- Öffne eine Datei:

`zathura {{pfad/zu/datei}}`

- Navigiere nach links/oben/unten/rechts:

`{{H|J|K|L|Pfeiltasten}}`

- Rotiere:

`r`

- Invertiere die Farben:

`<Strg> + R`

- Durchsuche den Text nach einem gegebenen String:

`/{{string}}`

- Erstelle/lösche Lesezeichen:

`:{{bmark|bdelete}} {{name_des_lesezeichens}}`

- Liste alle Lesezeichen auf:

`:blist`
