# lzma

> Este comando é um alias de `xz`.

- Exibe documentação do comando original:

`tldr xz`
