# ghostname

> 这是 `hostname` 命令的一个别名。

- 原命令的文档在：

`tldr hostname`
