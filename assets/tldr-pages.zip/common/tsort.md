# tsort

> Perform a topological sort.
> A common use is to show the dependency order of nodes in a directed acyclic graph.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/tsort-invocation.html>.

- Perform a topological sort consistent with a partial sort per line of input separated by blanks:

`tsort {{path/to/file}}`

- Perform a topological sort consistent on strings:

`echo -e "{{UI Backend\nBackend Database\nDocs UI}}" | tsort`
