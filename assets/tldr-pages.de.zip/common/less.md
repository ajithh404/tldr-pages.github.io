# less

> Öffne eine Datei für interaktives lesen, erlaubt scrollen und suchen.
> Weitere Informationen: <https://greenwoodsoftware.com/less/>.

- Öffne eine Datei:

`less {{pfad/zu/datei}}`

- Scrolle eine Seite runter / hoch:

`{{<Space>|<b>}}`

- Springe zum Ende / Anfang der Datei:

`{{<G>|<g>}}`

- Suche nach einer Zeichenkette vorwärts (`<n>`/`<N>` um zur nächsten/vorherigen Übereinstimmung zu springen):

`</>{{suche}}`

- Suche nach einer Zeichenkette rückwärts (`<n>`/`<N>` um zur nächsten/vorherigen Übereinstimmung zu springen):

`<?>{{suche}}`

- Folge der Ausgabe des geöffneten Buffers:

`<F>`

- Öffne die Datei in einem Editor:

`<v>`

- Beende `less`:

`<q>`
