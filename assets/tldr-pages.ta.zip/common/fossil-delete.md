# fossil delete

> இக்கட்டளை `fossil rm` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr fossil rm`
