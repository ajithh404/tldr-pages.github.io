# glibtool

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `-p linux libtool`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr {{[-p|--platform]}} linux libtool`
