# apt-cache

> Eina de consulta de paquets per a Debian y Ubuntu.
> Més informació: <https://manned.org/apt-cache.8>.

- Busca un paquete en les teves fonts actuals:

`apt-cache search {{consulta}}`

- Mostra informació de un paquet:

`apt-cache show {{paquet}}`

- Mostra si un paquet està instalat i actualitzat:

`apt-cache policy {{paquet}}`

- Mostra les dependències de un paquet:

`apt-cache depends {{paquet}}`

- Mostra els paquets que depenen de un paquet en particular:

`apt-cache rdepends {{paquet}}`
