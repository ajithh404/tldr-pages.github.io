# gpupdate

> Check and apply Windows Group Policy settings.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/gpupdate>.

- Check and apply updated Group Policy settings:

`gpupdate`

- Specify the target Group Policy settings to check for update:

`gpupdate /target:{{computer|user}}`

- Force all Group Policy settings to be reapplied:

`gpupdate /force`

- Display help:

`gpupdate /?`
