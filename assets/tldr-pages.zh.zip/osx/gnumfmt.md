# gnumfmt

> 这是 `-p linux numfmt` 命令的一个别名。

- 原命令的文档在：

`tldr -p linux numfmt`
