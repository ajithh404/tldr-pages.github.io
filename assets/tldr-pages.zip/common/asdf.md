# asdf

> Manage versions of different packages.
> More information: <https://asdf-vm.com/manage/commands.html>.

- List all available plugins:

`asdf plugin list all`

- Install a plugin:

`asdf plugin add {{name}}`

- List all available versions for a package:

`asdf list all {{name}}`

- Install a specific version of a package:

`asdf install {{name}} {{version}}`

- Set global version for a package:

`asdf set -u {{name}} {{version}}`

- Set local version for a package:

`asdf set {{name}} {{version}}`

- See the current version used for a package:

`asdf current {{name}}`
