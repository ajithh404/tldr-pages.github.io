# gtsort

> Este comando es un alias de `-p linux tsort`.

- Muestra la documentación del comando original:

`tldr -p linux tsort`
