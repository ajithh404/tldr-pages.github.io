# gchroot

> यह आदेश `-p linux chroot` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr -p linux chroot`
