# ping

> 向网络主机发送 ICMP 回显请求数据包。
> 更多信息：<https://keith.github.io/xcode-man-pages/ping.8.html>.

- Ping 指定的主机：

`ping "{{主机}}"`

- 对主机执行指定定次数的 ping 操作：

`ping -c {{次数}} "{{主机}}"`

- Ping 主机 , 指定请求之间的间隔（以秒为单位）（默认为 1 秒）：

`ping -i {{秒}} "{{主机}}"`

- Ping 主机, 但不尝试查找地址的符号名：

`ping -n "{{主机}}"`

- Ping 主机 并在收到数据包时响铃（如果您的终端支持）：

`ping -a "{{主机}}"`

- Ping 主机 并打印接收数据包的时间（此选项是 Apple 的附加项）：

`ping --apple-time "{{主机}}"`
