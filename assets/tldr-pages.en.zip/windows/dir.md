# dir

> List directory contents.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/dir>.

- Show the contents of the current directory:

`dir`

- Show the contents of a given directory:

`dir {{path\to\directory}}`

- Show the contents of the current directory, including hidden ones:

`dir /a`

- Show the contents of a given directory, including hidden ones:

`dir {{path\to\directory}} /a`

- Show a bare list of directories and files, with no additional information:

`dir /b`

- Sort results by date/time, oldest first:

`dir /o:d`
