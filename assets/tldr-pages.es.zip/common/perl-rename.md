# perl-rename

> Este comando es un alias de `rename`.

- Vea la documentación del comando original:

`tldr -p common rename`
