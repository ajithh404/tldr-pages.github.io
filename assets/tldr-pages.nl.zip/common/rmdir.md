# rmdir

> Verwijder directories zonder bestanden.
> Bekijk ook: `rm`.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/rmdir-invocation.html>.

- Verwijder specifieke directories:

`rmdir {{pad/naar/map1 pad/naar/map2 ...}}`

- Verwijder specifieke geneste directories recursief:

`rmdir -p {{pad/naar/map1 pad/naar/map2 ...}}`
