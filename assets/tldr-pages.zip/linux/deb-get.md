# deb-get

> `apt-get` functionality for `.deb` packages published in third party repositories or via direct download.
> Works with Linux distributions which use `apt-get`.
> More information: <https://github.com/wimpysworld/deb-get>.

- Update the list of available packages and versions:

`deb-get update`

- Search for a given package:

`deb-get search {{package}}`

- Show information about a package:

`deb-get show {{package}}`

- Install a package, or update it to the latest available version:

`deb-get install {{package}}`

- Remove a package (using `purge` instead also removes its configuration files):

`deb-get remove {{package}}`

- Upgrade all installed packages to their newest available versions:

`deb-get upgrade`

- List all available packages:

`deb-get list`
