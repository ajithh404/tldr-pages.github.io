# distrobox-rm

> Remove a Distrobox container.
> See also: `distrobox`.
> More information: <https://distrobox.it/usage/distrobox-rm>.

- Remove a Distrobox container (Tip: Stop the container before removing it):

`distrobox-rm {{container_name}}`

- Remove a Distrobox container forcefully:

`distrobox-rm {{container_name}} {{[-f|--force]}}`
